# Anonymous DDOS ![version](https://img.shields.io/badge/version-1.0.0-blue.svg)

## Installation

- Intall [Node.JS](https://nodejs.org/)

- `npm i`

## Start

`npm start`

## Stop

`Ctrl + C`

## Edit URL

- open package.json
- change url in `scripts.start` line
- save file